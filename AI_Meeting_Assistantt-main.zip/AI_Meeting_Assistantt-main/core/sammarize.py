from langchain_mistralai import ChatMistralAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda,RunnablePassthrough
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.output_parsers import StrOutputParser

import os

def get_llm():
    return ChatMistralAI(model = 'mistral-small-latest',mistral_api_key = os.getenv('MISTRAL_API_KEY'),temperature = 0.3)

def split_transcript(transcript: str)-> str:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size = 3000,
        chunk_overlap = 200
    )

    return splitter.split_text(transcript)

def summarize(transcript: str) -> str:
    llm = get_llm()

    map_prompt = ChatPromptTemplate.from_messages([
        ('system','summarize this protion of a meeting transcript concisely.'),
        ('human','{text}')
    ])

    map_chain = map_prompt | llm | StrOutputParser()

    chunks = split_transcript(transcript)

    chunk_summaries = [map_chain.invoke({'text':chunk}) for chunk in chunks]

    combained = '\n\n'.join(chunk_summaries)

    combained_prompt = ChatPromptTemplate.from_messages([
        ('system','you are an expert meeting summarizer. combine these partial summaries'),
        ('human','{text}'),
    ])

    combained_chain = (
        RunnablePassthrough() | RunnableLambda(lambda x : {'text':x}) | combained_prompt | llm | StrOutputParser()
    )

    return combained_chain.invoke(combained)

def generate_title(transcript:str) -> str:
    llm = get_llm()

    title_chain = (
        RunnablePassthrough() | RunnableLambda(lambda x:{'text':x}) |
        ChatPromptTemplate.from_messages([
            ('system','based on the meeting transcript, generate a short professional meeting title (max 8 words). Only retur the title, nothing else'),
            ('human','{text}')
        ]) | llm | StrOutputParser()
    )

    return title_chain.invoke(transcript[:2000])